#include <iostream>
#include "date.h"
using namespace std;

int main{
    int date ,month,year;
    cin >> year >> month >> date;
    Date(month,day,year);
    return 0;
}